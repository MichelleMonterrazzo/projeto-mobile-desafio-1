import React, { createContext, useState, useEffect } from "react";
import { Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import authService from "../service/auth";
import { auth } from "../firebaseConfig";
import {
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from "firebase/auth";

const usuarioContext = {
  logado: false,
  usuario: {},
  loading: false,
  login: () => new Promise(),
  logout: () => {},
};

const AuthContext = createContext(usuarioContext);

export const AuthProvider = ({ children }) => {
  const [usuario, setUsuario] = useState({});
  const [loading, setLoading] = useState(true);

  // Obter usuário autenticado ao iniciar
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setUsuario(user);
        AsyncStorage.setItem("@NRAuth:user", JSON.stringify(user));
      } else {
        setUsuario({});
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Salvar dados no AsyncStorage
  const salvarStorage = async (usuario) => {
    await AsyncStorage.setItem("@NRAuth:user", JSON.stringify(usuario));
  };

  // Login com Firebase
  const login = async (email, senha) => {
    setLoading(true);
    try {
      const response = await signInWithEmailAndPassword(auth, email, senha);
      setUsuario(response.user);
      await salvarStorage(response.user);
    } catch (error) {
      Alert.alert("Erro de Login", error.message);
    } finally {
      setLoading(false);
    }
  };

  // Logout com Firebase
  const logout = async () => {
    setLoading(true);
    try {
      await signOut(auth);
      await AsyncStorage.clear();
      setUsuario({});
    } catch (error) {
      Alert.alert("Erro ao sair", error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{ logado: !!usuario.uid, usuario, loading, login, logout }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;
