import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth/web-extension";

const firebaseConfig = {
  apiKey: "AIzaSyAXrDP1M_6UHus1x4NcWo_TpZ95m-Ao744",
  authDomain: "projeto-mobile-91a2e.firebaseapp.com",
  projectId: "projeto-mobile-91a2e",
  storageBucket: "projeto-mobile-91a2e.firebasestorage.app",
  messagingSenderId: "731153298382",
  appId: "1:731153298382:web:618578c1caf68b9f4b719f",
  measurementId: "G-K4S3QFDFL8"
};


export const firebase = initializeApp(firebaseConfig);
export const auth = getAuth(firebase);
const analytics = getAnalytics(firebase);
