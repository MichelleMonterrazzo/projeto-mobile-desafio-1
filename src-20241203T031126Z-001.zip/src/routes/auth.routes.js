//Arquivo que tera todas as rotas que não precisa de autenticação

import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

const AuthStack = createNativeStackNavigator();

import Login from "../pages/Login";
import recuperarSenha from "../pages/RecuperarSenha";
import RecuperarSenhaPage from "../pages/RecuperarSenhaPage";
import CadastroPage from "../pages/CadastroPage";
import Cadastro from "../pages/Cadastro";

export default function AuthRoutes() {
  return (
    <AuthStack.Navigator initialRouteName="Login">
      <AuthStack.Screen
        name="Login"
        component={Login}
        options={{}}
      ></AuthStack.Screen>
      <AuthStack.Screen
        name="Recuperar Senha"
        component={recuperarSenha}
        options={{}}
      ></AuthStack.Screen>
      <AuthStack.Screen
        name="RecuperarSenhaPage"
        component={RecuperarSenhaPage}
        options={{ title: "Recuperar Senha" }}
      ></AuthStack.Screen>
      <AuthStack.Screen
        name="CadastroPage"
        component={CadastroPage}
        options={{}}
      ></AuthStack.Screen>

      <AuthStack.Screen
        name="Cadastro"
        component={Cadastro}
        options={{}}
      ></AuthStack.Screen>
    </AuthStack.Navigator>
  );
}
