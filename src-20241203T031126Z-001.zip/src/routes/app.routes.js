import React from "react";
import { createDrawerNavigator } from '@react-navigation/drawer';
import Home from "../pages/Home";
import Servicos from "../pages/Servicos";
import Sobre from "../pages/Sobre";
import CustomDrawer from "../components/Drawer/CustomDrawer";


const Drawer = createDrawerNavigator();

function AppRoutes() {
  return (
    <Drawer.Navigator
      initialRouteName="Início" 
      drawerContent={(props) => <CustomDrawer {...props} />} 
    >
      <Drawer.Screen name="Início" component={Home} />
      <Drawer.Screen name="Serviços" component={Servicos} />
      <Drawer.Screen name="Sobre" component={Sobre} />

    </Drawer.Navigator>
  );
}

export default AppRoutes;
