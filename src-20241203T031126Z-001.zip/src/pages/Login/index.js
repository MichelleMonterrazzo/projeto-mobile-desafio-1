import React, { useContext, useState } from "react";
import { Alert, StyleSheet, View } from "react-native";
import MeuInput from "../../components/Input";
import SuperButton from "../../components/SuperButton";
import AuthContext from "../../contexts/auth";
import RecuperarSenha from "../RecuperarSenha";
import Titulo from "../../components/Title";
import Cadastro from "../Cadastro";

export default function Login() {
  const { login } = useContext(AuthContext);
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const handlerLogin = () => {
    if (!email.trim() || !senha.trim()) {
      Alert.alert("Erro", "Preencha todos os campos!");
      return;
    }

    login(email, senha);
  };

  return (
    <View style={styles.container}>
      <Titulo titulo="Login" />
      <MeuInput
        label="E-mail"
        placeholder="Informe seu email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />
      <MeuInput
        label="Senha"
        placeholder="Informe sua senha"
        value={senha}
        onChangeText={setSenha}
        secureTextEntry
      />

      <RecuperarSenha />

      <SuperButton valor="Entrar" callback={handlerLogin} />

      <Cadastro />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
