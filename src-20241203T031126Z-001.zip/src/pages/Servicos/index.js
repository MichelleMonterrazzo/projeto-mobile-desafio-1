import React, { useContext } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import { useTheme } from '../../contexts/ThemeContext';  // Importe o contexto de tema

const Servicos = () => {
  const { isDarkMode } = useTheme(); // Pegue o tema atual (escuro ou claro)

  return (
    <View style={[styles.container, { backgroundColor: isDarkMode ? '#333' : '#FFE8D7' }]}>
      <Text style={[styles.title, { color: isDarkMode ? '#fff' : '#f24405' }]}>
        Nossos Serviços
      </Text>

      <View style={styles.serviceContainer}>
        <Text style={[styles.serviceTitle, { color: isDarkMode ? '#f24405' : '#333' }]}>
          Consultas Médicas
        </Text>
        <Text style={[styles.subtitle, { color: isDarkMode ? '#aaa' : '#666' }]}>
          Oferecemos consultas presenciais e online com médicos especializados em diversas áreas.
        </Text>
      </View>

      <View style={styles.serviceContainer}>
        <Text style={[styles.serviceTitle, { color: isDarkMode ? '#f24405' : '#333' }]}>
          Atendimento Online
        </Text>
        <Text style={[styles.subtitle, { color: isDarkMode ? '#aaa' : '#666' }]}>
          Realize consultas de onde você estiver, com a mesma qualidade do atendimento presencial.
        </Text>
      </View>

      <View style={styles.beneficioContainer}>
        <Text style={[styles.beneficioTitle, { color: isDarkMode ? '#f24405' : '#333' }]}>
          Benefícios de escolher DoctorHappy
        </Text>
        <Text style={[styles.beneficioText, { color: isDarkMode ? '#aaa' : '#666' }]}>
          Atendimento rápido e eficiente, médicos especializados, e cuidado contínuo.
        </Text>
      </View>

      <TouchableOpacity style={[styles.button, { backgroundColor: isDarkMode ? '#444' : '#f24405' }]}>
        <Text style={styles.buttonText}>Agendar Consulta</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
  },
  title: {
    fontSize: 32,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
  },
  serviceContainer: {
    marginBottom: 30,
  },
  serviceTitle: {
    fontSize: 20,
    fontWeight: "bold",
  },
  subtitle: {
    fontSize: 16,
    marginTop: 10,
  },
  beneficioContainer: {
    marginTop: 40,
  },
  beneficioTitle: {
    fontSize: 20,
    fontWeight: "bold",
  },
  beneficioText: {
    fontSize: 16,
    marginTop: 10,
  },
  button: {
    paddingVertical: 15,
    borderRadius: 35,
    marginTop: 30,
    alignItems: "center",
  },
  buttonText: {
    fontSize: 18,
    color: "#fff",
    fontWeight: "bold",
  },
});

export default Servicos;
