import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { useNavigation } from "@react-navigation/native"; // Hook para navegação

export default function RecuperarSenha() {
  const navigation = useNavigation();

  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={() => navigation.navigate("RecuperarSenhaPage")}
      >
        <Text style={styles.text}>Esqueci a senha</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    justifyContent: "flex-end",
    width: "100%",
    paddingHorizontal: 35,
    marginBottom: 15,
  },
  text: {
    color: "#EA9459",
    fontWeight: "bold",
    fontSize: 13,
  },
});
