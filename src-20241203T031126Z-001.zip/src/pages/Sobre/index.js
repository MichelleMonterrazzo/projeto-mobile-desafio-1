import React, { useContext } from "react";
import { View, Text, StyleSheet, Image } from "react-native";
import { useTheme } from '../../contexts/ThemeContext';  // Importe o contexto de tema

function Sobre() {
  const { isDarkMode } = useTheme();  // Pegue o estado atual do tema

  return (
    <View style={[styles.container, { backgroundColor: isDarkMode ? '#333' : '#FFE8D7' }]}>
      <Text style={[styles.subTitle, { color: isDarkMode ? '#F24405' : '#F24405' }]}>
        SOBRE NÓS
      </Text>
      <Text style={[styles.title, { color: isDarkMode ? '#fff' : '#333' }]}>
        Entenda quem somos e por que existimos
      </Text>
      <Text style={[styles.paragraph, { color: isDarkMode ? '#ccc' : '#333' }]}>
        Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet
        sint. Velit officia consequat duis enim. Amet minim mollit non deserunt
        ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis
        enim. Amet minim mollit non deserunt ullamco est sit aliqua dolor do
        amet sint. Velit officia consequat duis enim.
      </Text>

      <Image
        source={require("../../../assets/doutora-feliz-atendendo-bebe.png")}
        style={styles.image}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  subTitle: {
    fontSize: 15,
    fontWeight: "bold",
    color: "#F24405", // Cor do subtítulo (mantenha no laranja)
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
  },
  paragraph: {
    fontSize: 16,
    marginBottom: 20,
  },
  image: {
    width: 325,
    height: 325,
    flex: 1,
    borderRadius: 12,
  },
});

export default Sobre;
