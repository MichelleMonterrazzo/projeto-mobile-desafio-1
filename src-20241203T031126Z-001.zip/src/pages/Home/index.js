import React, { useContext } from "react";
import { Text, View, StyleSheet, Image } from "react-native";
import { useTheme } from "../../contexts/ThemeContext";

function Home() {
  const { isDarkMode } = useTheme();

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: isDarkMode ? "#333" : "#FFE8D7" },
      ]}
    >
      <Text style={[styles.subTitle, { color: isDarkMode ? "#fff" : "#333" }]}>
        BOAS-VINDAS A DOCTORHAPPY
      </Text>
      <Text style={[styles.title, { color: isDarkMode ? "#fff" : "#000" }]}>
        Cuidando da sua saúde com alegria e dedicação!
      </Text>
      <Text style={[styles.paragraph, { color: isDarkMode ? "#fff" : "#333" }]}>
        Na DoctorHappy, nossos médicos não só tratam os sintomas, mas se
        preocupam com o seu bem-estar de forma completa, trazendo soluções que
        vão direto à raiz do problema.
      </Text>
      <Text
        style={[
          styles.paragraph2,
          { color: isDarkMode ? "#F24405" : "#F24405" },
        ]}
      >
        Sorria! pois aqui você está em boas mãos e a cura está no caminho da
        felicidade!
      </Text>
      <Image
        source={require("../../../assets/mulher-sorrindo.png")}
        style={styles.image}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  subTitle: {
    fontSize: 15,
    marginBottom: 15,
    textAlign: "center",
    fontWeight: "bold",
  },
  title: {
    fontSize: 30,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  paragraph: {
    fontSize: 16,
    textAlign: "center",
  },
  paragraph2: {
    fontSize: 16,
    marginBottom: 15,
    textAlign: "center",
    fontWeight: "bold",
  },
  image: {
    width: 300,
    height: 300,
    marginBottom: 20,
  },
});

export default Home;
