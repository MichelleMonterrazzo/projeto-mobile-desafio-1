import React from "react";
import { TouchableHighlight, StyleSheet, View, Text, Alert } from "react-native";

function SuperButton (props){
    return(
        <TouchableHighlight 
            style={style.superButton}
            onPress={props.callback}
            >
            <View style={style.button}>
                <Text style={style.valor}>{props.valor}</Text>
            </View>
        </TouchableHighlight>
    );
}

const style = StyleSheet.create({
    superButton:{

    },
    button:{
        alignItems:'center',
        borderRadius:19,
        backgroundColor:'#283FB1',
        padding:12,
        width:300, 
        color:'#fff'
    },
    valor:{
        fontSize:20,
        color:'#fff',
        fontWeight:'bold'
    }
});

export default SuperButton;