import React from "react";
import { Text, StyleSheet } from "react-native";


function Titulo(){
    return(
    <Text style={css.titulo} >Login</Text>
    );
}


const css = StyleSheet.create({
    titulo: {
       color: '#283FB1',
       fontSize: 36,
       paddingBottom: 50,
       paddingRight: 210,
       fontWeight:'600'
    }
});

export default Titulo
