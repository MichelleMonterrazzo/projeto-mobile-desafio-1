import React from "react";
import { StyleSheet, SafeAreaView, Text, TextInput } from "react-native";

function MeuInput(props) {
  return (
    <SafeAreaView>
      <Text style={{ color: "#888888" }}>{props.label}</Text>
      <TextInput
        style={style.input}
        placeholder={props.placeholder}
        secureTextEntry={props.secureTextEntry}
        keyboardType={props.keyboardType}
        onChangeText={props.onChangeText}
        value={props.value}
      ></TextInput>
    </SafeAreaView>
  );
}

const style = StyleSheet.create({
  input: {
    borderColor: "#888888",
    borderWidth: 1,
    borderRadius: 18,
    height: 42,
    marginBottom: 15,
    marginTop: 10,
    padding: 10,
    width: 300,
  },
});

export default MeuInput;
