import React from "react";
import { Button, Alert } from "react-native";

function MyButton(props){
    return(
        <Button 
        title={props.titulo}
        color="blue"
        onPress={()=> Alert.alert('Aqui eu farei o login') }
        />
    );
}

export default MyButton;
