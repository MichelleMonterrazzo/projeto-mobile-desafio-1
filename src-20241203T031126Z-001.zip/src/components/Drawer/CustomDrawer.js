import React, { useContext } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import AuthContext from '../../contexts/auth';  
import { useTheme } from '../../contexts/ThemeContext'; 

function CustomDrawer(props) {
  const { logout } = useContext(AuthContext); 
  const { isDarkMode, toggleTheme } = useTheme(); 

  return (
    <View style={[styles.container, { backgroundColor: isDarkMode ? '#333' : '#fff' }]}>
      
      <View style={styles.titleContainer}>
       
        <View>
          <Text style={[styles.titleText, { color: isDarkMode ? '#fff' : '#000' }]}>Doctor</Text>
          <Text style={[styles.titleTextHappy, { color: isDarkMode ? '#F24405' : '#F24405' }]}>Happy</Text>
        </View>

      
        <TouchableOpacity onPress={toggleTheme} style={styles.iconContainer}>
          <Image
            source={isDarkMode ? require('../../../assets/sun-icon.png') : require('../../../assets/moon-icon.png')}
            style={styles.icon}
          />
        </TouchableOpacity>
      </View>

     
      <TouchableOpacity onPress={() => props.navigation.navigate('Início')} style={styles.drawerItem}>
        <Text style={[styles.drawerText, { color: isDarkMode ? '#fff' : '#000' }]}>Início</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => props.navigation.navigate('Serviços')} style={styles.drawerItem}>
        <Text style={[styles.drawerText, { color: isDarkMode ? '#fff' : '#000' }]}>Serviços</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => props.navigation.navigate('Sobre')} style={styles.drawerItem}>
        <Text style={[styles.drawerText, { color: isDarkMode ? '#fff' : '#000' }]}>Sobre</Text>
      </TouchableOpacity>

     
      <TouchableOpacity onPress={logout} style={styles.drawerItem}>
        <Text style={[styles.logoutText, { color: isDarkMode ? '#F23005' : '#F23005' }]}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 50,
    paddingHorizontal: 20,
  },
  titleContainer: {
    flexDirection: 'row',  
    justifyContent: 'space-between', 
    alignItems: 'center', 
    marginBottom: 40, 
  },
  titleText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  titleTextHappy: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#F24405',
  },
  iconContainer: {
    padding: 5,
    borderRadius: 10, 
  }, 
  icon: {
    width: 30,  
    height: 30,
  },
  drawerItem: {
    paddingVertical: 15,
  },
  drawerText: {
    fontSize: 18,
  },
  logoutText: {
    fontSize: 18,
    marginTop: 350,
    fontWeight: 'bold',
  },
});

export default CustomDrawer;
